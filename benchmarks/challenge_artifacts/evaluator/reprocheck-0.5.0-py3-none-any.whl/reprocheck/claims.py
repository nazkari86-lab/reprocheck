from __future__ import annotations

import html
import re
from typing import Literal

from .metric_names import (
    METRIC_ALIASES,
    canonical_metric,
    is_unit_interval_metric,
    metric_family,
)
from .models import Claim, ClaimCheck

_ALIASES = "|".join(sorted((re.escape(k) for k in METRIC_ALIASES), key=len, reverse=True))
_NUMBER = r"[+-]?(?:\d+(?:[.,]\d*)?|[.,]\d+)(?:[eE][+-]?\d+)?"
_CLAIM_RE = re.compile(
    rf"(?<![\w])(?P<metric>{_ALIASES})(?![\w])\s*(?:score|метрика)?\s*"
    rf"(?:=|:|of|at|составил[аи]?|достигл[аи]?|равна?|на\s+уровне)?"
    rf"\s*(?P<value>{_NUMBER})"
    rf"\s*(?P<percent>%)?",
    flags=re.IGNORECASE,
)
_NUMBER_RE = re.compile(rf"(?P<value>{_NUMBER})\s*(?P<percent>%)?")
_STRUCTURED_KEY_RE = re.compile(
    rf"(?<![\w])(?P<metric>[\w²][\w².-]*)\s*:\s*"
    rf"(?P<value>{_NUMBER})\s*(?P<percent>%)?",
    flags=re.IGNORECASE,
)
_PARAMETER_TOKENS = {"threshold", "thresh", "cutoff", "nms", "weight", "loss"}


def extract_claims(text: str) -> list[Claim]:
    claims: list[Claim] = []
    seen: set[tuple[int, str, float]] = set()
    lines = text.splitlines()
    for line_number, line in enumerate(lines, start=1):
        for match in _STRUCTURED_KEY_RE.finditer(line):
            metric = _structured_metric_name(match.group("metric"))
            if metric is None:
                continue
            value = _normalize_value(
                metric,
                float(match.group("value").replace(",", ".")),
                percent=bool(match.group("percent")),
            )
            key = (line_number, metric, value)
            if key not in seen:
                seen.add(key)
                claims.append(
                    Claim(metric=metric, value=value, raw_text=line.strip(), line=line_number)
                )
        for match in _CLAIM_RE.finditer(line):
            alias = match.group("metric").lower()
            metric = METRIC_ALIASES[alias]
            if metric in {"iou", "hard_iou"} and _is_nms_parameter(line, match.start()):
                continue
            value = _normalize_value(
                metric,
                float(match.group("value").replace(",", ".")),
                percent=bool(match.group("percent")),
            )
            key = (line_number, metric, value)
            if key in seen:
                continue
            seen.add(key)
            claims.append(
                Claim(metric=metric, value=value, raw_text=line.strip(), line=line_number)
            )
    for claim in _extract_markdown_table_claims(lines):
        key = (claim.line, claim.metric, claim.value)
        if key not in seen:
            seen.add(key)
            claims.append(claim)
    claims.sort(key=lambda claim: claim.line)
    return claims


def _structured_metric_name(raw_name: str) -> str | None:
    canonical = canonical_metric(raw_name)
    tokens = set(re.split(r"[_.-]+", canonical))
    if tokens & _PARAMETER_TOKENS:
        return None
    family = metric_family(canonical)
    if family is None:
        return None
    return family if canonical == family else canonical


def _extract_markdown_table_claims(lines: list[str]) -> list[Claim]:
    claims: list[Claim] = []
    index = 0
    while index + 1 < len(lines):
        headers = _split_table_row(lines[index])
        separators = _split_table_row(lines[index + 1])
        if not headers or not separators or not _is_separator_row(separators):
            index += 1
            continue
        metrics = [_metric_from_header(header) for header in headers]
        row_index = index + 2
        while row_index < len(lines):
            cells = _split_table_row(lines[row_index])
            if not cells:
                break
            for column, metric in enumerate(metrics):
                if metric is None or column >= len(cells):
                    continue
                value = _table_value(metric, cells[column])
                if value is not None:
                    claims.append(
                        Claim(
                            metric=metric,
                            value=value,
                            raw_text=lines[row_index].strip(),
                            line=row_index + 1,
                        )
                    )
            row_index += 1
        index = max(row_index, index + 1)
    return claims


def _split_table_row(line: str) -> list[str] | None:
    if "|" not in line:
        return None
    stripped = line.strip()
    if stripped.startswith("|"):
        stripped = stripped[1:]
    if stripped.endswith("|"):
        stripped = stripped[:-1]
    cells = [cell.strip() for cell in stripped.split("|")]
    return cells if len(cells) >= 2 else None


def _is_separator_row(cells: list[str]) -> bool:
    return bool(cells) and all(re.fullmatch(r":?-{3,}:?", cell.replace(" ", "")) for cell in cells)


def _plain_cell(value: str) -> str:
    value = re.sub(r"<br\s*/?>", " ", value, flags=re.IGNORECASE)
    value = re.sub(r"<[^>]+>", " ", value)
    value = re.sub(r"!?(?:\[([^]]*)\])\([^)]*\)", r"\1", value)
    value = re.sub(r"[`*_~]", "", value)
    return re.sub(r"\s+", " ", html.unescape(value)).strip()


def _metric_from_header(header: str) -> str | None:
    plain = _plain_cell(header).casefold().replace("_", " ")
    compact = re.sub(r"[^\w²]+", " ", plain, flags=re.UNICODE).strip()
    if re.search(r"\bm\s*ap\b|\bmap", compact):
        if re.search(r"50\s+95", compact):
            return "map50_95"
        if re.search(r"\b75\b", compact):
            return "map75"
        if re.search(r"\b50\b", compact):
            return "map50"
    if re.search(r"\bmiou\b|\bmean\s+iou\b", compact):
        return "miou"
    if re.search(r"\btop\s*1\b", compact) and re.search(r"\bacc(?:uracy)?\b", compact):
        return "top1_accuracy"
    if re.search(r"\btop\s*5\b", compact) and re.search(r"\bacc(?:uracy)?\b", compact):
        return "top5_accuracy"
    for alias in sorted(METRIC_ALIASES, key=len, reverse=True):
        normalized_alias = re.sub(r"[^\w²]+", " ", alias.casefold(), flags=re.UNICODE).strip()
        if normalized_alias and re.search(rf"(?<!\w){re.escape(normalized_alias)}(?!\w)", compact):
            return METRIC_ALIASES[alias]
    return None


def _table_value(metric: str, cell: str) -> float | None:
    match = _NUMBER_RE.search(_plain_cell(cell))
    if match is None:
        return None
    value = float(match.group("value").replace(",", "."))
    return _normalize_value(metric, value, percent=bool(match.group("percent")))


def _normalize_value(metric: str, value: float, *, percent: bool) -> float:
    if percent or (is_unit_interval_metric(metric) and 1 < value <= 100):
        return value / 100.0
    return value


def _is_nms_parameter(line: str, metric_start: int) -> bool:
    prefix = line[max(0, metric_start - 12) : metric_start]
    return bool(re.search(r"\bNMS\s*$", prefix, flags=re.IGNORECASE))


def check_claims(
    claims: list[Claim],
    observed_metrics: dict[str, float],
    tolerance: float,
    evidence_levels: dict[str, Literal["reported", "recomputed"]] | None = None,
) -> list[ClaimCheck]:
    checks: list[ClaimCheck] = []
    for claim in claims:
        observed = observed_metrics.get(claim.metric)
        if observed is None:
            checks.append(
                ClaimCheck(
                    claim=claim,
                    status="no_evidence",
                    observed=None,
                    difference=None,
                    tolerance=tolerance,
                    evidence_level=None,
                )
            )
            continue
        difference = abs(claim.value - observed)
        evidence_level: Literal["reported", "recomputed"] = (evidence_levels or {}).get(
            claim.metric, "reported"
        )
        matched_status = "verified" if evidence_level == "recomputed" else "supported"
        checks.append(
            ClaimCheck(
                claim=claim,
                status=matched_status if difference <= tolerance else "mismatch",
                observed=observed,
                difference=difference,
                tolerance=tolerance,
                evidence_level=evidence_level,
            )
        )
    return checks
